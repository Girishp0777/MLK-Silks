const jwt = require('jsonwebtoken');

const validation= async(req, res, next)=>{
    const cookie = req.headers.cookie;
    const token= cookie?.split("=")[1];

    jwt.verify(token, process.env.JWT_EMPLOYEE_KEY, (Error, newemployee)=>{
        if(Error){
            if (Error.name === 'TokenExpiredError') {
                return res.status(400).json({message: "Token has expired",newemployee});
              }
            return res.status(400).json({message:" Signin Please"});
        }
        console.log("Decoded Employee",newemployee.id);
        req.newemployee = newemployee.id;
        next();
    });
};

module.exports= validation;