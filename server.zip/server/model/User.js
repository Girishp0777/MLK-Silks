const mongoose=require('mongoose')
const UserSchema= new mongoose.Schema(
    {
        FirstName:
        {
            type:String,
            lowercase:true,
            required:true,
        },
        MiddleName:
        {
            type:String,
            lowercase:true,
        },
        LastName:
        {
            type:String,
            lowercase:true,
            required:true,
        },
        Gender:
        {
            type:String,
            required:true,
            enum:['male','female','non-binary','prefer not say'],
           },
        Dob:
        {
            type:Date,
            required:true,
        },
        MobileNumber1:
        {
            type:Number,
            maxlength:10,
            minlength:10,
            required:true,
        },
        MobileNumber2:
        {
            type:Number,
            maxlength:10,
            minlength:10, 
        },
        Emailid:
        {
            type:String,
            required:[true,"Please Enter the email"],
            Unique: [true,"this email is already exists"],
            lowercase:true,
            trim:true,
            validate:{
                validator:function(value){
                    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
                },
                message: props => `${props.value} is a not valid Email Address`
     
            },
        },
        Password:
        {
            type:String,
            required:true,
            minlength:8,
            maxlength:123,
        },
        AddressFullName:
        {
            type:String,
        },
        Address1:
        {
            type:String,         
        },
        Address2:
        {
            type:String,        
        },
        LineMarks:
        {
            type:String,
        },
        City:
        {
            type:String,
        },
        State:
        {
            type:String,
        },
        PinCode:
        {
            type:String,
        },
        UserId:
        {
            type:mongoose.Schema.Types.ObjectId,
        },

        }
    
);
module.exports=mongoose.model('User',UserSchema,"User");