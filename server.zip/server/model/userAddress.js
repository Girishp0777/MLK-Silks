const mongoose = require('mongoose');

const userAddressSchema = mongoose.Schema({
    addressFullName:{
        type:String,
        required:true
    },
    AddressOne:{
        type:String,
        required:true
    },
    AddressTwo:{
        type:String,
        required:true
    },
    linemarks:{
        type:String,
        required:true
    },
    city:{
        type:String,
        required:true
    },
    state:{
        type:String,
        required:true
    },
    pincode:{
        type:Number,
        minlength:6,
        maxlength:6,
        required:true
    },
    mobileOne:{
        type:Number,
        maxlength:10,
        minlength:10,
        required:true
    },
    mobileTwo:{
        type:Number,
        maxlength:10,
        minlength:10,
        required:true
    },
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        required:true
    }
});

module.exports= mongoose.model('useraddress', userAddressSchema, "useraddress");