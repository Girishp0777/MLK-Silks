const mongoose=require('mongoose')
const SellerSchema=new mongoose.Schema(
    {
      admin_id:
      {
        type:mongoose.Schema.Types.ObjectId,
        ref:'admin'
      },
       FirstName:
       {
        type:String,
        required:true,
        lowercase:true,   
       },
       MiddleName:
       {
        type:String,
        lowercase:true,
       },
       LastName:
       {
        type:String,
        required:true,
        lowercase:true,
       },
       Gender:
       {
        type:String, 
        required:true,
        enum:['male','female','non-binary','prefer not say'],
       },
       Dob:
       {
        type:String,
        required:true,
       },
       MobileNumber1:
       {
        type:Number,
        minlength:10,
        maxlength:10,
        required:true,
       },
       MobileNumber2:
       {
        type:Number,
        minlength:10,
        maxlength:10,
       },
       Emailid:
       {
        type:String,
        required:[true,"Please Enter the email"],
        // Unique: [true,"this email is already exists"],
        lowercase:true,
        trim:true,
        validate:{
            validator:function(value){        
                return /^[\w-\.]+@gmail\.com$/.test(value);
            },
            message: props => `${props.value} is a not valid Email Address`
 
        },
    },
      
       Password:
       {
        type: String,
        required: true,
        minlength: 8,
        maxlength: 128,
        // validate: {
        //     validator: function(value) {
        //         return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/.test(value);
        //     },
        //     message: props => `${props.value} is not a strong password!`,
        // },
       },
       aadharCard:
       {
        type:Number,
        minlength:10,
        maxlength:10,
        required:true, 
       },
       OutletName:
       {
        type:String,
        required:true,
       },
       GSTNumber:
       {
        type:String,
        required:true,
       },
       RegisterNumber:
       {
        type:String,
        required:true,
       },
       Outletaddress1:
       {
        type:String,
        required:true,
       },
       Outletaddress2:
       {
        type:String,
    },
    LineMarks:
    {
        type:String,
        required:true,
    },
    City:
      {
         type:String,
         required:true,
      },
      State:
      {
        type:String,
        required:true,
      },
      PinCode:
      {
        type:Number,
        minlength:6,
        maxlength:6,
        required:true,
      },
      OutleEmail:
      {
        type:String,
        required:[true,"Please Enter the email"],
        Unique: [true,"this email is already exists"],
        lowercase:true,
        trim:true,
        validate:{
            validator:function(value){        
                return /^[\w-\.]+@gmail\.com$/.test(value);
            },
            message: props => `${props.value} is a not valid Email Address`
 
        },
      },
      Officephone:
      {
        type:Number,
        minlength:10,
        maxlength:10,
        required:true,
      },
      Officephone2:
      {
        type:Number,
        minlength:10,
        maxlength:10,   
      },
      SellerPassportPhoto: 
      {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        },
        
      },
      Outletphoto1:
      {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        },
      
      },
      Outletphoto2:
      {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        },
      
      },
      Outletphoto3:
      {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        },
       
      },
      Outletphoto4:
      {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        },
       
      },

    }
);
module.exports=mongoose.model('Seller',SellerSchema,"Seller");