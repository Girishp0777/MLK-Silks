const express=require('express');
const router=express.Router();
const SellerController=require('../../controller/sellerController/AUth/SellerRegister');
const authController = require('../../controller/sellerController/AUth/Auth');

router.post('/create',SellerController.seller_create);

router.delete('/sellerdelete/:id',SellerController.seller_delete);
router.patch('/upadate/:id',SellerController.seller_update);
router.get('/display/:id',SellerController.seller_display_by_id);
router.get('/read',SellerController.seller_get);


router.post('/signup',authController.signup);
router.post('/login',authController.login);
router.get("/getuser",authController.verifyToken,authController.getUser);
router.post("/logout",authController.verifyToken,authController.logout);


module.exports=router;