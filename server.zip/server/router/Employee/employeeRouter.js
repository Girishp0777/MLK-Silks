const express = require('express')
const router = express.Router();
const employeeregister= require('../../controller/employeeController/AUth/Register');
const crudemployee= require('../../controller/employeeController/AUth/Auth');
const crudproduct= require('../../controller/employeeController/productsCrud');
const crudseller= require('../../controller/employeeController/sellerCrud');
const employeevalidation= require('../../middleware/Employee/employeevalidation');

//Employee Authorization
router.route('/signup').post(employeeregister.signup);

router.route('/signin').post(employeeregister.signin);

router.route('/current').get(employeevalidation, employeeregister.currentEmployee);

router.route('/signout').post(employeeregister.signout);


//Employee CrudOperations
router.route('/allemployee').get(employeevalidation, crudemployee.getallemployee);

router.route('/employeeid/:id').get(employeevalidation, crudemployee.getallemployeeid);

router.route('/updateemployee/:id').put(employeevalidation, crudemployee.updateemployee);

router.route('/deleteemployee/:id').put(employeevalidation, crudemployee.deleteemployee);


//FOR PRODUCT CRUDS
router.route('/allproductemp').get(employeevalidation, crudproduct.allproductsemp);

router.route('/createproductemp').post(employeevalidation, crudproduct.createproductemp);

router.route('/productidemp/:id').get(employeevalidation, crudproduct.productsidemp);

router.route('/updateproductemp/:id').put(employeevalidation, crudproduct.updateproductemp);

router.route('/deleteproductemp/:id').delete(employeevalidation, crudproduct.deleteproductemp);


//FOR Seller CRUDS
router.route('/allselleremp').get(employeevalidation, crudseller.allselleremp);

router.route('/createselleremp').post(employeevalidation, crudseller.createselleremp);

router.route('/selleridemp/:id').get(employeevalidation, crudseller.selleridemp);

router.route('/updateselleremp/:id').put(employeevalidation, crudseller.updateselleremp);

router.route('/deleteselleremp/:id').delete(employeevalidation, crudseller.deleteseller);




module.exports = router;