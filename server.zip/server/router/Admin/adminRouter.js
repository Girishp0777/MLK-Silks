const express= require('express');
const router= express.Router();
const AdminController=require('../../controller/adminController/AUth/Register');
const adminValidation= require('../../middleware/Admin/adminvalidation');
const refreshtoken= require('../../middleware/Admin/adminrefesh');
const adminCrud=require('../../controller/adminController/AUth/Auth');
const sellerCrud=require('../../controller/adminController/sellerCrud');
const employeeCrud=require('../../controller/adminController/employeeCrud');
const productCrud=require('../../controller/adminController/productsCrud');
const EDashboard= require('../../controller/adminController/dashBoardadmin');

//FOR ADMIN AUTHROIZATION
router.route('/adminsignin').post(AdminController.signin);

router.route('/adminverify').get(adminValidation, AdminController.currentAdmin);

router.route('/signout').post(AdminController.signout);

router.route('/adminrefresh').get(refreshtoken,  AdminController.currentAdmin);


//FOR ADMIN CRUDS
router.route('/adminsignin').get(adminCrud.getadmin);

router.route('/adminid/:id').get(adminValidation, adminCrud.adminbyid);

router.route('/updateadmin/:id').put(adminValidation, adminCrud.updateadmin);

router.route('/deleteadmin/:id').delete(adminValidation, adminCrud.deleteadmin);

router.route('/adminsignin').get(adminCrud.getadmin);

router.route('/refreshadminid/:id').get(refreshtoken, adminCrud.adminbyid);

router.route('/refreshupdateadmin/:id').put(refreshtoken, adminCrud.updateadmin);

router.route('/refreshdeleteadmin/:id').delete(refreshtoken, adminCrud.deleteadmin);


//FOR SELLER CRUDS
router.route('/allseller').get(adminValidation, sellerCrud.getseller);

router.route('/createseller').post(adminValidation, sellerCrud.creatseller);

router.route('/sellerid/:id').get(adminValidation, sellerCrud.sellerbyid);

router.route('/updateseller/:id').put(adminValidation, sellerCrud.sellerupdate);

router.route('/deleteseller/:id').delete(adminValidation, sellerCrud.deleteseller);

router.route('/refreshallseller').get(refreshtoken, sellerCrud.getseller);

router.route('/refreshcreateseller').post(refreshtoken, sellerCrud.creatseller);

router.route('/refreshsellerid/:id').get(refreshtoken, sellerCrud.sellerbyid);

router.route('/refreshupdateseller/:id').put(refreshtoken, sellerCrud.sellerupdate);

router.route('/refreshdeleteseller/:id').delete(refreshtoken, sellerCrud.deleteseller);


//FOR EMPLOYEE CRUDS
router.route('/allemployee').get(adminValidation, employeeCrud.getemployee);

router.route('/createemployee').post( adminValidation, employeeCrud.createemployee);

router.route('/employeeid/:id').get(adminValidation, employeeCrud.employeebyid);

router.route('/updateemployee/:id').put(adminValidation, employeeCrud.employeeupdate);

router.route('/deleteemployee/:id').delete(adminValidation, employeeCrud.deleteemployee);

router.route('/refreshallemployee').get(refreshtoken, employeeCrud.getemployee);

router.route('/refreshcreateemployee').post(refreshtoken, employeeCrud.createemployee);

router.route('/refreshemployeeid/:id').get(refreshtoken, employeeCrud.employeebyid);

router.route('/refreshupdateemployee/:id').put(refreshtoken, employeeCrud.employeeupdate);

router.route('/refreshdeleteemployee/:id').delete(refreshtoken, employeeCrud.deleteemployee);


//FOR PRODUCT CRUDS
router.route('/allproduct').get(adminValidation, productCrud.getproduct);

router.route('/createproduct').post(adminValidation, productCrud.addproducts);

router.route('/productid/:id').get(adminValidation, productCrud.productbyid);

router.route('/updateproduct/:id').put(adminValidation, productCrud.updateproduct);

router.route('/deleteproduct/:id').delete(adminValidation, productCrud.deleteproduct);

router.route('/refreshallproduct').get(refreshtoken, productCrud.getproduct);

router.route('/refreshcreateproduct').post(refreshtoken, productCrud.addproducts);

router.route('/refreshproductid/:id').get(refreshtoken, productCrud.productbyid);

router.route('/refreshupdateproduct/:id').put(refreshtoken, productCrud.updateproduct);

router.route('/refreshdeleteproduct/:id').delete(refreshtoken, productCrud.deleteproduct);



//Dashboard

router.route('/employeedashboard').get(EDashboard.emloyees);

router.route('/sellerdashboard').get(EDashboard.sellers);

router.route('/productdashboard').get(EDashboard.products);


module.exports=router;