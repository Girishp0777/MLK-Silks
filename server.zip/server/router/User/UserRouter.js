const express=require('express');
const router=express.Router();
const UserController=require('../../controller/userController/AUth/UserRegister');
const  authController=require('../../controller/userController/AUth/Auth');

const UserProducts=require('../../controller/userController/Userproducts');  //userproducts

router.post('/create',UserController.User_create);
router.delete('/userdelete/:id',UserController.User_delete);
router.patch('/update/:id',UserController.User_update);
router.get('/display/:id',UserController.User_display_by_id);
router.get('/read',UserController.User_get);


router.post("/signin",authController.signin);
router.post("/login",authController.login);
router.get("/getUser",authController.verifyToken,authController.getUser);
router.post("/logout",authController.verifyToken,authController.logout);

//USER PRODUCTS

router.delete('/userdelete/:id',UserProducts.Userproducts_delete);
router.get('/display/:id',UserProducts.Userproducts_display_by_id);
router.get('/byname/:Name',UserProducts.Userproducts_byname);
router.get('/read',UserProducts.Userproducts_get);


//FOR UserAddress CRUDS
// router.route('/alluseraddressemp').get(crudseller.allselleremp);

// router.route('/createselleremp').post(crudseller.createselleremp);

// router.route('/selleridemp/:id').get(crudseller.selleridemp);

// router.route('/updateselleremp/:id').put(crudseller.updateselleremp);

// router.route('/deleteselleremp/:id').delete(crudseller.deleteseller);


module.exports=router;