const express=require('express');
const router=express.Router();
const productsController=require('../../controller/sellerController/productsCrud');

router.post('/productscreate',productsController.productspost);
router.delete('/delete/:id',productsController.products_delete);
router.get('/display/:id',productsController.products_display_by_id);
router.patch('/update/:id',productsController.products_update);
router.get('/byname/:Name',productsController.products_byname);
router.get('/read',productsController.products_get);

module.exports=router;
