const Crud =require('../../model/User');


const Userproducts_display_by_id=async(req,res)=>
{
    try{
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
          res.status(404).json(
            {
                'error':"sorry id is not found"
            }
          );

        }
        else{
            res.json(crud);
        }
    }
    catch{
        res.status(500).json(
            {
                "error":"Internal server error"
            }
        );
    }
};

const Userproducts_byname=async(req,res)=>
{
    try{
       const crud=await Crud.findOne({Name:req.params.UserId});
       if(!crud) 
       {
        res.status(404).json(
            {
                'error':"data not found"
            }
        );
       }
       else{
        res.json(crud);
       }
    }
    catch{
        res.status(500).json(
            {
                "error":"Internal server error"
            }
        );
    }
};

const Userproducts_delete=async(req,res)=>
{
    try{
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );
        }
        else{
            await Crud.findByIdAndDelete(req.params.id);
            res.status(200).json(
                {
                    "message":"products delete"
                }
            );
        }
    }
    catch{
        console.log(Crud);
        res.status(500).json(
            {
                "error":"Internal server error"
            }
        );
    }
};
const Userproducts_get=async(req,res)=>
{
    try{
        const crud=await Crud.find().exce();
    if(crud)
    {
        res.json(crud);
    }
    else
    {
        res.status(500).json(
            {
                "error":"please login"
            }
        );
    }
    }
    catch(error)
    {
        console.log("cannot find data from database");
    }
}


module.exports={
    Userproducts_byname,
    Userproducts_delete,
    Userproducts_display_by_id,
    Userproducts_get
};