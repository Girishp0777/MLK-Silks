const address = require('../../model/userAddress');

const alladdress = async(req, res)=>{
    try{
        const UserAddress= await address.find();
        if(!UserAddress){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(UserAddress);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const createaddress = async(req, res)=>{
    try{
        const addressFullName= req.body.addressFullName;
        const AddressOne= req.body.AddressOne;
        const AddressTwo= req.body.AddressTwo;
        const linemarks= req.body.linemarks;
        const city= req.body.city;
        const state= req.body.state;
        const pincode= req.body.pincode;
        const mobileOne= req.body.mobileOne;
        const mobileTwo= req.body.mobileTwo;

        const newAddress= new address({
            addressFullName, AddressOne, AddressTwo, linemarks, city, state, pincode, mobileOne, mobileTwo,
            userId
        });
        await newAddress.save().then((newAddress)=>{
            return res.status(200).json({message:"Address Added Sucessfully",newAddress});
        });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const addressid = async(req, res)=>{
    try{
        const UserAddress= await address.findById(req.params.id);
        if(!UserAddress){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(UserAddress);
        } 
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

const updateaddress =async(req, res)=>{
    try{
        const UserAddress= await address.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true}
            );
        if(!UserAddress){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(UserAddress);
        } 
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const deleteaddress = async(req, res)=>{
    try{
        const UserAddress= await address.findByIdAndDelete(req.params.id);
        if(!UserAddress){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(UserAddress);
        } 
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"})
    }
};


module.exports= {alladdress, createaddress, addressid, updateaddress, deleteaddress};