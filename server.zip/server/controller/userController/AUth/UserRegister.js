const Crud = require('../../../model/User');

const User_create=(req,res)=>
{
    let crud=new Crud(req.body);

    crud.save().then((crud)=>
    {
        res.send(crud);
    })
    .catch((error)=>
    {
        res.status(400).json(
            {
                'msg':'pls provide correct information'
            }
        );
        console.log("error in controller",error)
    });
};

const User_update=async(req,res)=>
{
    try{
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );
        }
        else{
            await Crud.findByIdAndUpdate(req.params.id,req.body);
            res.status(200).json(
                {
                    "meesage":"User updated"
                }
            );
        }
    }
    catch{
        res.status(500).json(
            {
                "error":"Internal server error"
            }
        );
    }
};
const User_delete=async(req,res)=>
{
    try{
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );
        }
        else{
            await Crud.findByIdAndDelete(req.params.id);
            res.status(200).json(
                {
                    "message":"User delete"
                }
            );
        }
    }
    catch{
        console.log(Crud);
        res.status(500).json(
            {
                "error":"Internal server error"
            }
        );
    }
};
const User_display_by_id=async(req,res)=>
{
    try{
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );
        }
        else{
            res.json(crud);
        }
        
    }
    catch{
        res.status(500).json(
            {
               "error":"Internal server error" 
            }
        );
    }  
};
const User_get=async(req,res)=>
{
    try{
        const crud=await Crud.find().exec();
        res.json(crud);
    }
    catch(error)
    {
        console.log("cannot find data from database")
    }
}

module.exports={
    User_create,
    User_delete,
    User_update,
    User_display_by_id,
    User_get
};