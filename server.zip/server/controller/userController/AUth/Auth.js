const Crud=require('../../../model/User');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');


const  signin=async(req,res)=>
{
    const{FirstName,MiddleName,LastName,Gender,Dob,MobileNumber1,MobileNumber2,AddressFullName, Emailid,Password, Address1,
         Address2,LineMarks,City,State,PinCode}=req.body;
    
    let exitingUser;
    try{
        exitingUser=await Crud.findOne({ Emailid:Emailid});
    }
    catch(err){
        console.log(err);
    }
    if(exitingUser)
    {
        return res.status(400).json(
            {
                message:"User already exits! Login Instead"
            }
        );
    }
     const hashedPassword = await bcrypt.hash(Password,10);
     console.log(hashedPassword);
     const User = new Crud(
        {
         FirstName,MiddleName,LastName,Gender,Dob, MobileNumber1, MobileNumber2,Emailid, PinCode,
         AddressFullName, Address1, Address2,City, State,LineMarks,
        
         Password:hashedPassword,
        
    
        }
     );
     try{
        await User.save();
        console.log(User);
        return res.status(200).json({message:"Data inserted succesfully",User});
     }
     catch(err)
     {
       console.log(err);
       return res.status(500).json({message:"Internal server error"});
     }
};
const login=async(req,res,next)=>
{
    const Emailid =req.body.Emailid;
    const Password =req.body.Password;
    let exitingUser;
    try{
        exitingUser= await Crud.findOne({Emailid});
    }
    catch(error)
    {
        return new Error(error);
    }
    if(!exitingUser)
    {
        return res.status(400).json(
            {
                message:"User not found.please signin..."

            }
        );
    }
    const isPasswordCorrect=await bcrypt.compare(Password,exitingUser.Password);
    if(!isPasswordCorrect)
    {
        return res.status(400).json(
            {
                message:"invalid email is or password"
            }
        );
    }
    const token = jwt.sign(
        {
            id:exitingUser.id
        },
        process.env.JWT_USER_KEY,
        {
            expiresIn:"120s",
        }
    );
    console.log("token is generated\n",token);
    if(req.cookies[`${exitingUser.id}`])
    {
        req.cookies[`${exitingUser.id}`]="";

    }
    res.cookie(String(exitingUser.id),token,
    {
        path:"/",
        expires:new Date(Date.now() + 1000 * 120),
        httpOnly:true,
        sameSite:"lax",
    });
    return res.status(200).json(
        {
            message:"successfully logged In..",
            User:exitingUser,token
        }
    );   
};

const verifyToken=(req,res,next)=>
{
    const cookies = req.headers.cookie;
    const token = cookies?.split('=')[1];
    console.log("cookies:",cookies);
    console.log("token:",token);

    jwt.verify(token,process.env.JWT_USER_KEY,(error,User)=>{
        {
         if(error)
         {
            if(error.name == 'TokenExpiredError'){
                return res.status(401).json({
                    message: "Token has expired",User
                });
            }
            res.status(404).json(
                {
                    message:"invalid token..."
                }
            );
         }        
        }
        console.log("Decoded user:",User.id);
        req.id=User.id;

        next();
     });
};
const getUser = async(req,res,next)=>
{
    const userId = req.id;
   console.log(userId);
    try{
        user=await Crud.findById(
          userId,"-Password" 
        );
    }
    catch(error)
    {
        console.log(error)
        return res.status(400).json(
            {
                message:"User not found..."
            }
        );
    }
    if(user)
    {
        return res.status(200).json(
            {
                user
            }
        )
    } 
};

const refreshToken=(req,res,next)=>
{
    const cookies =req.headers.cookies;
    const Pretoken  = cookies?.split("=")[1];

    if(!Pretoken)
    {
        console.log(Pretoken);
        res.status(400).json(
            {
                message:"couldn't find token"
            }
        );
    }
    jwt.verify(String(Pretoken),process.env.JWT_USER_KEY,(err,User)=>{
        if(err){
            return res.status(400).json({message:"invalid token"});
        }
        res.clearCookies(`${User.id}`);
        req.cookies[`${User.id}`]="";

        const token=jwt.sign({id:User.id},process.env.JWT_USER_KEY,{
            expiresIn:"120s",
        });
        console.log("Regenerated Token",token);
        res.cookies(String(exitingUser.id),token,{
            path:"/",
            expires:new Date(Date.now()+1000*120),
            httpOnly:true,
            sameSite:"lax",
        });
        req.id = User.id;
        next();
    })
};
const logout=(req,res,next)=>
{
    const cookies=req.headers.cookies;
    const Pretoken=cookies.split('=')[1];
    console.log(cookies);
    if(!Pretoken)
    {
        console.log(Pretoken);
        res.status(400).json(
        {
            message:"couldn't find token",
        }
        );
    }
    jwt.verify(String(Pretoken),process.env.JWT_USER_KEY,(error,User)=>{
        if(error){
            console.log(error);
            return res.status(400).json({message:"invalid token or empty token",
        });
        }
        res.clearCookies(`${User.id}`);
        req.cookies[`${User.id}`]="";
        return res.status(400).json({
            message:"Successfully logged out"
     });
    });
}

module.exports={
    signin,
    login,
    verifyToken,
    getUser,
    refreshToken,
    logout
};
