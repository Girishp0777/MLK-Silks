const employee= require('../../model/Employee');
const multer =require('multer');
const path =require('path');
const bcrypt= require('bcrypt')

const getemployee= async(req, res)=>{
    try{
        const Employee= await employee.find();
        if(!Employee){
            return res.status(404).json({message:"Employees Not Found"});
        }else{
            return res.status(200).json(Employee);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const employeebyid= async(req, res)=>{
    try{
        const Employee= await employee.findById(req.params.id);
        if(!Employee){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Employee);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const storage= multer.diskStorage({
    destination:path.join("employee/Images"),
    filename:function(req, file, cb){
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
});


const fileFilter = (req, file, cb)=>{
    const filetypes= ['image/jpeg', 'image/jpg', 'image/png', 'image/pdf'];
    if(filetypes.includes(file.mimetype)){
        cb(null, true);
    }else{
        cb(null, false);
    }
};


const upload = multer({
    storage:storage,
    limits:{fileSize:100000},
    fileFilter:fileFilter
}).fields([
    { name: "uidNumber", maxCount: 1 },
    { name: "panNumber", maxCount: 1 },
    { name: "passportPhoto", maxCount: 1 },
    { name: "Signature", maxCount: 1 }
]);

const createemployee= async(req, res)=>{
    try{
        upload(req, res, async(Error)=>{
            if(Error){
                console.log(Error);
                return res.status(404).json({message:"Multer Error"});
            }

            if(!req.files || !req.files.uidNumber || !req.files.panNumber || !req.files.passportPhoto || !req.files.Signature ){
                console.log("Images Are Not Selected");
                return res.status(404).json({message:"Images Are Not Selected"});
            }else{
                const uidNumber={
                    data:req.files.uidNumber[0].buffer,
                    contentType:req.files.uidNumber[0].mimetype,
                    path:path.join("employee", "Images", req.files.uidNumber[0].filename)
                };

                const panNumber={
                    data:req.files.panNumber[0].buffer,
                    contentType:req.files.panNumber[0].mimetype,
                    path:path.join("employee", "Images", req.files.panNumber[0].filename)
                };

                const passportPhoto={
                    data:req.files.passportPhoto[0].buffer,
                    contentType:req.files.passportPhoto[0].mimetype,
                    path:path.join("employee", "Images", req.files.passportPhoto[0].filename)
                };

                const Signature={
                    data:req.files.Signature[0].buffer,
                    contentType:req.files.Signature[0].mimetype,
                    path:path.join("employee", "Images", req.files.Signature[0].filename)
                };

                console.log("Images uploaded successfully");


                const { FirstName, MidName, LastName, Gender, Dob, Mobile1, Mobile2, email, Password, aadharCard, panCard, 
                schoolName, SchoolSubject, SchoolPercentage, SecounderySchoolName, SecounderySchoolSubject, SecounderySchoolPercentage, PrimerySchoolName,
                PrimerySchoolSubject, PrimerySchoolPercentage, addressFullName, AddressOne, AddressTwo, linemarks, 
                city, state, pincode, mobileOne, mobileTwo } = req.body

                const isStrongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/.test(Password);
                if (!isStrongPassword) {
                    return res.status(400).json({ message: "Password is not strong enough" });
                }

                const existingemployee= await employee.findOne({email});
                if(existingemployee){
                    return res.status(400).json({message:"This Email Id is Already Exists"});
                }

                const ispassword = await bcrypt.hash(Password, 10);
                const newemployee= new employee({
                    FirstName, MidName, LastName, Gender, Dob, Mobile1, Mobile2, email, aadharCard, panCard, 
                    schoolName, SchoolSubject, SchoolPercentage, SecounderySchoolName, SecounderySchoolSubject, SecounderySchoolPercentage,
                    PrimerySchoolName, PrimerySchoolSubject, PrimerySchoolPercentage, addressFullName, AddressOne, 
                    AddressTwo, linemarks, city, state, pincode, mobileOne, mobileTwo,
                    uidNumber:uidNumber,
                    panNumber:panNumber,
                    passportPhoto:passportPhoto,
                    Signature:Signature,
                    Password:ispassword,
                });

                await newemployee.save().then((newemployee) =>{
                    return res.status(200).json({message:"Registered Sucessfully",newemployee});
                });
            }
        });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

const employeeupdate= async(req, res)=>{
    try{
        const Update= await employee.findByIdAndUpdate(
            req.params.id,
            req.files,
            {new:true}
            );
        if(!Update){
            return res.status(404).json({message:"Internal Server Error"});
        }else{
            return res.status(200).json(Update);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const deleteemployee= async(req, res)=>{
    try{
        const Employee= await employee.findByIdAndDelete(req.params.id);
        if(!Employee){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Employee);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

module.exports={getemployee, employeebyid, createemployee, employeeupdate, deleteemployee};