const seller= require('../../model/Seller');
const product= require('../../model/Products')

const emloyees= async(req, res)=>{
    try{
        const Total= await seller.countDocuments();
        const Male= await seller.countDocuments({Gender:"male"});
        const Female= await seller.countDocuments({Gender:"female"});
        return res.status(200).json({Total,Male,Female});
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const sellers= async(req, res)=>{
    try{
        const Total = await seller.countDocuments();
        return res.status(200).json({Total});
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const products = async(req, res)=>{
    try{
        const Total= await product.countDocuments();
        return res.status(200).json({Total});
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


module.exports={emloyees, sellers, products};