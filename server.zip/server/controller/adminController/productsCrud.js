const multer = require('multer');
const path =require('path');
const product = require('../../model/Products');

const getproduct= async(req, res)=>{
    try{
        const Product= await product.find();
        if(!Product){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Product);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const storage = multer.diskStorage({
    destination:path.join("product/Images"),
    filename: function(req, file, cb){
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb)=>{
    const fileType =['image/jpeg', 'image/jpg', 'image/png' , 'image/pdf'];
    if(fileType.includes(file.mimetype)){
        cb(null, true)
    }
    else{
        cb(null, false)
    }
};

const upload =  multer({
    storage:storage,
    limits:{fileSize:1000000},
    fileFilter:fileFilter
}).fields([
    {name:"MainImage", maxCount:1},
    {name:"Image2", maxCount:1},
    {name:"Image3", maxCount:1},
    {name:"Image4", maxCount:1},
    {name:"Image5", maxCount:1}
]);

const addproducts= async(req, res)=>{
    try{
        upload(req, res, async(err)=>{
            if(err){
                console.log(err);
                return res.status(404).json({message:"Multer Error"});
            }

            if(!req.files || !req.files.MainImage || !req.files.Image2 || !req.files.Image3 || !req.files.Image4 || !req.files.Image5){
                return res.status(404).json({message:"Images Are Not Selected"});
            }

            const MainImage={
                data:req.files.MainImage[0].buffer,
                contentType:req.files.MainImage[0].mimetype,
                path:path.join("product", "Images", req.files.MainImage[0].filename)
            };

            const Image2={
                data:req.files.Image2[0].buffer,
                contentType:req.files.Image2[0].mimetype,
                path:path.join("product", "Images", req.files.Image2[0].filename)
            };

            const Image3={
                data:req.files.Image3[0].buffer,
                contentType:req.files.Image3[0].mimetype,
                path:path.join("product", "Images", req.files.Image3[0].filename)
            };

            const Image4={
                data:req.files.Image4[0].buffer,
                contentType:req.files.Image4[0].mimetype,
                path:path.join("product", "Images", req.files.Image4[0].filename)
            };

            const Image5={
                data:req.files.Image5[0].buffer,
                contentType:req.files.Image5[0].mimetype,
                path:path.join("product", "Images", req.files.Image5[0].filename)
            };
            const {Title, SubTitle, MRP, Discount, SellingPrice, Category, SubCategory}=req.body;

            const sellingPrice= ((MRP/Discount) * 100)*MRP;

            const Product = new product({
                Title, SubTitle, MRP, Discount, Category, SubCategory,
                SellingPrice:sellingPrice,
                MainImage:MainImage,
                Image2:Image2,
                Image3:Image3,
                Image4:Image4,
                Image5:Image5
            });
            await Product.save().then((Product)=>{
                return res.status(200).json({ message: "Data inserted successfully", Product });
            });
            console.log(Product);
        });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const productbyid= async(req, res)=>{
    try{
        const Product = await product.findById(req.params.id);
        if(!Product){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Product);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const updateproduct=async(req, res)=>{
    try{
        const Updated = await product.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true}
        );
        if(!Updated){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Updated);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

const deleteproduct= async(req, res)=>{
     try{
        const Product = await product.findByIdAndDelete(req.params.id);
        if(!Product){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Product);
        }
     }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
     }
};


module.exports={getproduct, addproducts, productbyid, updateproduct, deleteproduct };























 