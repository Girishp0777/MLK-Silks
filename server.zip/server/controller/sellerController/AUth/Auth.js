const Crud =require('../../../model/Seller');
const bcrypt = require('bcryptjs');
const jwt= require('jsonwebtoken');
const multer =require('multer');
const path = require('path');
 


const storage = multer.diskStorage({
    destination: path.join("public/image"),
    filename: function (req, file, cb) {
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
  });
  
  const fileFilter = (req, file, cb) => {
    const allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedFileTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limits: { fileSize: 100000000 },
    fileFilter: fileFilter,
  }).fields([
    { name: "SellerPassportPhoto", maxCount: 1 },
    { name: "Outletphoto1", maxCount: 1 },
    { name: "Outletphoto2", maxCount: 1 },
    { name: "Outletphoto3", maxCount: 1 },
    { name: "Outletphoto4", maxCount: 1 },
  ]);
  
  
const signup= async(req, res)=>{
    try{
        upload(req, res, async (err) => {

              if (err) {
                  console.log("Multer error", err);
                  return res.status(400).json({ error: "File uploading failed" });
              }

              if (!req.files || !req.files.SellerPassportPhoto || !req.files.Outletphoto1 || !req.files.Outletphoto2 ||  !req.files.Outletphoto3 ||  !req.files.Outletphoto4) {
                  console.log(err);
                  return res.status(400).json({ error: "Images or Images1 not selected" });
              }

              const SellerPassportPhoto = {
                  data: req.files.SellerPassportPhoto[0].buffer,
                  contentType: req.files.SellerPassportPhoto[0].mimetype,
                  path: path.join("public", "Images", req.files.SellerPassportPhoto[0].filename),
              };

              const Outletphoto1 = {
                  data: req.files.Outletphoto1[0].buffer,
                  contentType: req.files.Outletphoto1[0].mimetype,
                  path: path.join("public", "Images", req.files.Outletphoto1[0].filename),
              };
              
              const Outletphoto2 = {
                data: req.files.Outletphoto2[0].buffer,
                contentType: req.files.Outletphoto2[0].mimetype,
                path: path.join("public", "Images", req.files.Outletphoto2[0].filename),
            };

            const Outletphoto3 = {
                data: req.files.Outletphoto3[0].buffer,
                contentType: req.files.Outletphoto3[0].mimetype,
                path: path.join("public", "Images", req.files.Outletphoto3[0].filename),
            };

            const Outletphoto4 = {
                data: req.files.Outletphoto4[0].buffer,
                contentType: req.files.Outletphoto4[0].mimetype,
                path: path.join("public", "Images", req.files.Outletphoto4[0].filename),
            };
              console.log("Images uploaded successfully");

              const { FirstName, MidName, LastName, Gender,  Emailid, Dob, MobileNumber1, MobileNumber2, aadharCard, OutletName, GSTNumber , RegisterNumber, Outletaddress1, Outletaddress2 , LineMarks, City, State, PinCode, OutleEmail, Officephone, Officephone2,  Password } = req.body;
              const existingSeller = await Crud.findOne({ Emailid });
              const hashedPassword = await bcrypt.hash(Password, 10);
              console.log(hashedPassword); 
              if (existingSeller) {
                  return res.status(400).json({ message: "User already exists. Try a different email id" });
              }


              const newseller = new Crud({
                FirstName, MidName, LastName, Gender,  Emailid, Dob, MobileNumber1, MobileNumber2, aadharCard, 
                OutletName, GSTNumber , RegisterNumber, Outletaddress1, Outletaddress2 , LineMarks, City, State, 
                PinCode, OutleEmail, Officephone, Officephone2,
                Password:hashedPassword,
                SellerPassportPhoto:SellerPassportPhoto,
                Outletphoto1:Outletphoto1,
                Outletphoto2:Outletphoto2,
                Outletphoto3:Outletphoto3,
                Outletphoto4:Outletphoto4

              });

              await newseller.save();
              console.log(newseller);
              return res.status(200).json({ message: "Data inserted successfully", newseller });
      });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

const login=async(req,res,next)=>
{
    const Emailid=req.body.Emailid;
    const Password=req.body.Password;
    let exitingUser;
    try{
        exitingUser=await Crud.findOne({Emailid:Emailid});
    }
    catch(error)
    {
        return new Error(error);    
    }
    if(!exitingUser)
    {
        return res.status(400).json(
            {
                message:"User not found.please sign in..."
            }
        );
    }
    const isPasswordCorrect=await bcrypt.compare(Password,exitingUser.Password);
    if(!isPasswordCorrect)
    {
        return res.status(400).json(
            {
                message:"invalid email or password"
            }
        );
    }
    const token =jwt.sign(
        {
            id:exitingUser._id
        },
        process.env.JWT_SELLER_KEY,
        {
            expiresIn:"120s",
        }
    );
    console.log("token is generted\n",token);
    if(req.cookies[`${exitingUser._id}`])
    {
        req.cookies[`${exitingUser._id}`]="";
    }
    res.cookie(String(exitingUser._id),token,
    {
        path:"/",
        expires:new Date(Date.now() + 1000 * 120),
        httpOnly:true,
        sameSite:"lax",
    });
   return res.status(200).json(
    {
        message:"successfully logged In..",
        User:exitingUser,token
    }
   );
};


const verifyToken=(req,res,next)=>
{
    const cookies=req.headers.cookie;
    const token=cookies?.split('=')[1];
    console.log("cookies : ", cookies);
    console.log("token : ", token);
 
    jwt.verify(token,process.env.JWT_SELLER_KEY,(error,User)=>{
        {
            if(error)
            {
                if(error.name == 'TokenExpiredError'){
                    return res.status(401).json({
                        message:"Token has expired",User
                    });
                }
                res.status(404).json(
                    {
                        message:"invalid Token..."
                    }
                );
            }
        }
        console.log("Decoded user:",User.id);
        req.id=User.id;
 
        next();
    });
};
 

const getUser=async(req,res,next)=>
{
    const userId=req.id;
    console.log(userId);
    try{
        user=await Crud.findById(
            userId,"-password"
        );
    }
    catch(error){
        console.log(error);
        return res.status(404).json(
            {
                message:"User not found...."
            }
        );
    }
    if(user){
        return res .status(200).json(
            {
                user
            }
        )
    };
}
const refreshToken =(req,res,next)=>
{
    const cookies=req.headers.cookies;
    const Pretoken=cookies?.split("=")[1];
 
    if(!Pretoken)
    {
        console.log(Pretoken);
        res.status(400).json(
            {
                message:"couldn't find token"
            }
        );
    }
 
jwt.verify(String(Pretoken),process.env.JWT_SELLER_KEY,(err,seller)=>{
    if(err){
        return res.status(400).json({message:"invalid token"});
    }
    res.clearCookies(`${User.id}`);
    req.cookies[`${User.id}`]="";
    const token=jwt.sign({id:User.id},process.env.JWT_SELLER_KEY,{
        expiresIn:"120s",
    });
    console.log("regenerated Token",token);
    res.cookies(String(exitingUser.id),token,{
        path:"/",
        expires:new Date(Date.now()+1000 *120),
        httpOnly:true,
        sameSite:"lax",
});
req.id = User.id;
next();
 
});
};
const logout =(req,res,next)=>
{
    const cookies=req.headers.cookie;
    const Pretoken=cookies.split('=')[1];
     console.log(cookies);
    if(!Pretoken)
    {
        console.log(Pretoken);
        res.status(400).json(
            {
                message:"couldn't find token",
            }
        );
    }
    jwt.verify(String(Pretoken),process.env.JWT_SELLER_KEY,(error,User)=>{
        if(error){
         console.log(error);
            return res.status(400).json({message:"invalid token or empty token",
        });
        }
        res.clearCookie(`${User.id}`);
        req.cookies[`${User.id}`]="";
        return res.status(400).json({
            message:"Successfully logged out"
        }); 
 
    });
   
};
module.exports={
    signup,
    login,
    verifyToken,
    getUser,
    refreshToken,
    logout
};