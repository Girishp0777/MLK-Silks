const Crud=require('../../../model/Seller');
const multer =require('multer');
const path = require('path');
const bcrypt=require('bcryptjs');

const storage = multer.diskStorage(
    {
        destination:path.join("public/image"),
        filename:function(req,file,cb)
        {
            cb(null, file.fieldname + Date.now() + path.extname(file.originalname))
        }
    }
);

const fileFilter = (req, file , cb)=>{
    const filetype=['image/jpg' , 'image/png', 'image/pdf'];
    if(filetype.includes(file.mimetype)){
        cb(null, true)
    }else{
        cb(null, false)
    }
};


const upload= multer({
    storage:storage,
    limites:{filesize:100000},
    fileFilter:fileFilter
}).fields([
    {name:"SellerPassportPhoto", maxCount:1},
    {name:"Outletphoto1", maxCount:1},
    {name:"Outletphoto2", maxCount:1},
    {name:"Outletphoto3", maxCount:1},
    {name:"Outletphoto4", maxCount:1}

]);

const seller_create=(req,res)=>  
{
    upload(req, res, async(err)=>{
 
        if(err){
            console.log(err);
            return res.status(400).json({message:"Multer Error"});
        }

        if(!req.files || !req.files.SellerPassportPhoto || !req.files.Outletphoto1 ||   !req.files.Outletphoto2 || !req.files.Outletphoto3 ||!req.files.Outletphoto4 ){
            return res.status(400).json({message:"Images Are Not Selected"});
        }
        let crud=new Crud({...req.body});
        crud.SellerPassportPhoto={
            data:req.files.SellerPassportPhoto[0].buffer,
            contentType:req.files.SellerPassportPhoto[0].mimetype,
            path:path.join("Public","Images", req.files.SellerPassportPhoto[0].filename)
        };

        crud.Outletphoto1={
            data:req.files.Outletphoto1[0].buffer,
            contentType:req.files.Outletphoto1[0].mimetype,
            path:path.join("Public","Images", req.files.Outletphoto1[0].filename)
        };

        crud.Outletphoto2 ={
            data:req.files.Outletphoto2[0].buffer,
            contentType:req.files.Outletphoto2[0].mimetype,
            path:path.join("Public","Images", req.files.Outletphoto2[0].filename)
        };

        crud.Outletphoto3 ={
            data:req.files.Outletphoto3[0].buffer,
            contentType:req.files.Outletphoto3[0].mimetype,
            path:path.join("Public","Images", req.files.Outletphoto3[0].filename)
        };

        crud.Outletphoto4 ={
            data:req.files.Outletphoto4[0].buffer,
            contentType:req.files.Outletphoto4[0].mimetype,
            path:path.join("Public","Images", req.files.Outletphoto4[0].filename)
        }; 


 crud.save()
        .then((crud)=>
        {
            res.send(crud);
        })
        

    .catch((error)=>
    {
        res.status(400).json(
            {
             'msg':'pls provide correct information'
            }
        
        );

     console.log("error in controller",error)   
    }
    );
});

};

const seller_update=async(req,res)=>
{
    try{
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );

        }
        else{
            await Crud.findByIdAndUpdate(req.params.id,req.body);
            res.status(200).json(
                {
                    "message":"products updated"
                }
            );

        }

    }
    catch{
        res.status(500).json(
            {
                "error":"Internal error"
            }
        );
    }
};
const seller_delete=async(req,res)=>
{
    try
    {
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );
        }
        else{
            await Crud.findByDelete(req.params.id);
            res.status(200).json(
                {
                    "message":"products delete"
                }
            );
        }

    }
    catch{
        console.log(Crud);
        res.status(500).json(
            {
                "error":"Intenal error"
            }
        );
    }

};
const seller_display_by_id=async(req,res)=>
{
    try
    {
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );
        }
        else{
            res.json(crud);

        }
    }
    catch{
        res.status(500).json(
            {
                "error":"Internal error"
            }
        );
    }
};
const seller_get=async(req,res)=>
{
    try{
        const crud=await Crud.find().exec();
        res.json(crud);
    }
    catch(error)
    {
        console.log("cannot find data from database")
    }
}


module.exports={
    seller_create,
    seller_update,
    seller_delete,
    seller_display_by_id,
    seller_get
};