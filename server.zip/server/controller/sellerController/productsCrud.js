 const {error}=require('console');
 const Crud=require('../../model/Products');
 const bcrypt = require('bcryptjs');
 const multer =require('multer');
 const path = require('path');` `
 
 const storage = multer.diskStorage({
    destination:path.join("product/image"),
    filename: function(req, file, cb){
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb)=>{
    const fileType =['image/jpeg', 'image/jpg', 'image/png' , 'image/pdf'];
    if(fileType.includes(file.mimetype)){
        cb(null, true)
    }
    else{
        cb(null, false)
    }
};

const upload =  multer({
    storage:storage,
    limits:{fileSize:1000000},
    fileFilter:fileFilter
}).fields([
    {name:"MainImage", maxCount:1},
    {name:"Image2", maxCount:1},
    {name:"Image3", maxCount:1},
    {name:"Image4", maxCount:1},
    {name:"Image5", maxCount:1}
]);

const productspost= async(req, res)=>{
    try{
        upload(req, res, async(err)=>{
            if(err){
                console.log(err);
                return res.status(404).json({message:"Multer Error"});
            }

            if(!req.files || !req.files.MainImage || !req.files.Image2 || !req.files.Image3 || !req.files.Image4 || !req.files.Image5){
                return res.status(404).json({message:"Images Are Not Selected"});
            }

            const MainImage={
                data:req.files.MainImage[0].buffer,
                contentType:req.files.MainImage[0].mimetype,
                path:path.join("product", "image", req.files.MainImage[0].filename)
            };

            const Image2={
                data:req.files.Image2[0].buffer,
                contentType:req.files.Image2[0].mimetype,
                path:path.join("product", "image", req.files.Image2[0].filename)
            };

            const Image3={
                data:req.files.Image3[0].buffer,
                contentType:req.files.Image3[0].mimetype,
                path:path.join("product", "image", req.files.Image3[0].filename)
            };

            const Image4={
                data:req.files.Image4[0].buffer,
                contentType:req.files.Image4[0].mimetype,
                path:path.join("product", "image", req.files.Image4[0].filename)
            };

            const Image5={
                data:req.files.Image5[0].buffer,
                contentType:req.files.Image5[0].mimetype,
                path:path.join("product", "image", req.files.Image5[0].filename)
            };
            const {Title, SubTitle, MRP, Discount, SellingPrice, Category, SubCategory}=req.body;

            const sellingPrice= ((MRP/Discount) * 100)*MRP;

            const Product = new Crud({
                Title, SubTitle, MRP, Discount, Category, SubCategory,
                SellingPrice:sellingPrice,
                MainImage:MainImage,
                Image2:Image2,
                Image3:Image3,
                Image4:Image4,
                Image5:Image5
            });
            await Product.save().then((Product)=>{
                return res.status(200).json({ message: "Data inserted successfully", Product });
            });
            console.log(Product);
        });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};
   
 const products_delete=async(req,res)=>
 {
    try{
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found"
                }
            );
        }
        else{
            await Crud.findByIdAndDelete(req.params.id);
            res.status(200).json(
                {
                    "message":"product delete"
                }
            );
        }
    }
    catch{
        console.log(Crud);
        res.status(500).json(
            {
                "error":"Internal server error"
            }
        );
    }
 };
 const products_display_by_id=async(req,res)=>
 {
    try
    {
        const crud=await Crud.findById(req.params.id);
        if(!crud)
        {
                res.status(404).json(
                    {
                        'error':"sorry id is not found"
                    }
                );           
        }
        else{ 
            res.json(crud);
        }
    }
    catch{
        res.status(500).json(
            {
                'error':"Internal error"
            }
        );
    }
 };
 const products_update=async(req,res)=>
 {
    try{
        const crud= await Crud.findById(req.params.id);
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"sorry id is not found..."
                }
            );
        }
        else{
            await Crud.findByAndUpdate(req.params.id);
            res.status(200).json(
                {
                    "message":"products updated..."
                }
            )
        }
    }
    catch{
        res.status(500).json(
            {
                "eroor":"Internal error"
            }
        );
    }
 };
 const  products_byname=async(req,res)=>
 {
    try{
        const crud=await Crud.findOne({Name:req.params.prouductsId});
        if(!crud)
        {
            res.status(404).json(
                {
                    'error':"data not found..."
                }
            );

        }
        else{
            res.json(crud);
        }
    }
    catch{
        res.status(500).json(
            { 
                'error':"Internal error......"
            }
        );
    }

 };
 const products_get=async(req,res,next)=>
 {
    try{
        const crud=await Crud.find().exce(); 
        res.json(crud);
    }
     catch(error)
     {
        console.log("cannot find data from database");
     }
 }
 module.exports={
    productspost,
    products_delete,
    products_display_by_id,
    products_update,
    products_byname,
    products_get
 };