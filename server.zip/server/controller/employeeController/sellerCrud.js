const seller= require('../../model/Seller');
const multer =require('multer');
const path = require('path');



const allselleremp = async(req, res)=>{
    try{
        const Sllers = await seller.find();
        if(!Sllers){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Sllers);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const selleridemp = async(req, res)=>{
    try{
        const Sllers = await seller.findById(req.params.id);
        if(!Sllers){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Sllers);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

const storage= multer.diskStorage({
    destination:path.join("public/Images"),
    filename: function(req, file, cb){
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb)=>{
    const filetype= ['image/jpeg', 'image/jpg', 'image/png', 'image/pdf'];
    if(filetype.includes(file.mimetype)){
        cb(null, true);
    }else{
        cb(null, false);
    }
};

const upload = multer({
    storage:storage,
    limits:{fileSize:100000},
    fileFilter:fileFilter
}).fields([
    { name: "SellerPassportPhoto", maxCount: 1 },
    { name: "Outletphoto1", maxCount: 1 },
    { name: "Outletphoto2", maxCount: 1 },
    { name: "Outletphoto3", maxCount: 1 },
    { name: "Outletphoto4", maxCount: 1 },
]);

const createselleremp = async(req, res)=>{
    try{
        upload(req, res, async(Error)=>{
            if(Error){
                console.log(Error);
                return res.status(404).json({message:"Multer Error"});
            }

            if (!req.files || !req.files.SellerPassportPhoto || !req.files.Outletphoto1 || !req.files.Outletphoto2 ||  !req.files.Outletphoto3 ||  !req.files.Outletphoto4) {
                console.log(Error);
                return res.status(400).json({ error: "Images or Images1 not selected" });
            }else{
                const SellerPassportPhoto = {
                    data:req.files.SellerPassportPhoto[0].buffer,
                    contentType:req.files.SellerPassportPhoto[0].mimeype,
                    path: path.join("public", "Images", req.files.SellerPassportPhoto[0].filename)
                };

                const Outletphoto1={
                    data:req.files.Outletphoto1[0].buffer,
                    contentType:req.files.Outletphoto1[0].mimetype,
                    path:path.join("public", "Images", req.files.Outletphoto1[0].filename)
                };

                const Outletphoto2= {
                    data:req.files.Outletphoto2[0].buffer,
                    contentType: req.files.Outletphoto2[0].mimetype,
                    path: path.join("public", "Images", req.files.Outletphoto2[0].filename)
                };

                const Outletphoto3={
                    data:req.files.Outletphoto3[0].buffer,
                    contentType:req.files.Outletphoto3[0].mimetype,
                    path: path.join("public", "Images", req.files.Outletphoto3[0].filename)
                };

                const Outletphoto4= {
                    data:req.files.Outletphoto4[0].buffer,
                    contentType:req.files.Outletphoto4[0].mimetype,
                    path: path.join("public", "Images", req.files.Outletphoto4[0].filename)
                };

                console.log("Image Uploaded Sucessfully");
            

            const { FirstName, MidName, LastName, Gender,  Emailid, Dob, MobileNumber1, MobileNumber2, aadharCard, OutletName, GSTNumber , RegisterNumber, Outletaddress1, Outletaddress2 , LineMarks, City, State, PinCode, OutleEmail, Officephone, Officephone2,  Password } = req.body;
            const existingSeller = await seller.findOne({ Emailid });
            const hashedPassword = await bcrypt.hash(Password, 10);
            console.log(hashedPassword); 
            if (existingSeller) {
                return res.status(400).json({ message: "User already exists. Try a different email id" });
            }


            const newseller = new seller({
              FirstName, MidName, LastName, Gender,  Emailid, Dob, MobileNumber1, MobileNumber2, aadharCard, 
              OutletName, GSTNumber , RegisterNumber, Outletaddress1, Outletaddress2 , LineMarks, City, State, 
              PinCode, OutleEmail, Officephone, Officephone2,
              Password:hashedPassword,
              SellerPassportPhoto:SellerPassportPhoto,
              Outletphoto1:Outletphoto1,
              Outletphoto2:Outletphoto2,
              Outletphoto3:Outletphoto3,
              Outletphoto4:Outletphoto4

            });

            await newseller.save().then((newseller)=>{
              return res.status(200).json({ message: "Data inserted successfully", newseller });
            });
            console.log(newseller);
        }
        });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
}


const updateselleremp = async(req, res)=>{
    try{
        const Sllers = await seller.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true}
            );
        if(!Sllers){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Sllers);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const deleteseller = async(req, res)=>{
    try{
        const Sllers = await seller.findByIdAndDelete(req.params.id);
        if(!Sllers){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(Sllers);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
}


module.exports= {allselleremp, createselleremp, selleridemp, updateselleremp, deleteseller};