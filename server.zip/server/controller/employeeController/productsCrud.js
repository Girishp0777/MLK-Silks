const product = require('../../model/Products');
const multer = require('multer');
const path =require('path');


const allproductsemp = async(req, res)=>{
    try{
        const products= await product.find();
        if(!products){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(products);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const productsidemp= async(req, res)=>{
    try{
        const products= await product.findById(req.params.id);
        if(!products){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(products);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Inteernal Server Error"});
    }
};

const storage= multer.diskStorage({
    destination: path.join("product/Images"),
    filename: function(req, file, cb){
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    } 
});

const fileFilter = (req, file, cb)=>{
    const filetype= ['image/jpeg', 'image/jpg', 'image/png', 'image/pdf'];
    if(filetype.includes(file.mimetype)){
        cb(null, true);
    }else{
        cb(null, false);
    }
};

const upload= multer({
    storage:storage,
    limits:{fileSize:100000},
    fileFilter:fileFilter
}).fields([
    {name:"MainImage", maxCount:1},
    {name:"Image2", maxCount:1},
    {name:"Image3", maxCount:1},
    {name:"Image4", maxCount:1},
    {name:"Image5", maxCount:1}
]);

const createproductemp = async(req, res)=>{
    try{
        upload(req, res, async(Error)=>{
            if(Error){
                console.log(Error);
                return res.status(404).json({message:"Multer Error"});
            }

            if(!req.files || !req.files.MainImage || !req.files.Image2 || !req.files.Image3 || !req.files.Image4 || !req.files.Image5){
                return res.status(404).json({message:"Images Are Not Selected"});
            }else{
                const MainImage={
                    data: req.files.MainImage[0].buffer,
                    contentType:req.files.MainImage[0].mimetype,
                    path:path.join("product","Images", req.files.MainImage[0].filename)
                };

                const Image2={
                    data:req.files.Image2[0].buffer,
                    contentType:req.files.Image2[0].mimetype,
                    path:path.join("product", "Images", req.files.Image2[0].filename)
                };

                const Image3={
                    data:req.files.Image3[0].buffer,
                    contentType:req.files.Image3[0].mimetype,
                    path:path.join("product", "Images", req.files.Image3[0].filename)
                };

                const Image4={
                    data:req.files.Image4[0].buffer,
                    contentType:req.files.Image4[0].mimetype,
                    path:path.join("product", "Images", req.files.Image4[0].filename)
                };

                const Image5={
                    data:req.files.Image5[0].buffer,
                    contentType:req.files.Image5[0].mimetype,
                    path:path.join("product", "Images", req.files.Image5[0].filename)
                };

                console.log("Image Uploaded Sucessfully");
            

            const {Title, SubTitle, MRP, Discount, SellingPrice, Category, SubCategory}=req.body;
            const sellingPrice= ((MRP/Discount) * 100)*MRP;

            const newproducts= new product({
                Title, SubTitle, MRP, Discount, Category, SubCategory,
                SellingPrice:sellingPrice,
                MainImage:MainImage,
                Image2:Image2,
                Image3:Image3,
                Image4:Image4,
                Image5:Image5
            });

            await newproducts.save().then((newproducts)=>{
                return res.status(200).json({ message: "Data inserted successfully", newproducts});
            })
            console.log(newproducts);
            }
        })
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const updateproductemp = async(req, res)=>{
    try{
        const products= await product.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true}
            );
        if(!products){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json({message:"Updated Sucessfully", products});
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const deleteproductemp = async(req, res)=>{
    try{
        const products= await product.findByIdAndDelete(req.params.id);
        if(!products){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json({message:"Deleted Sucessfully", products})
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal server Error"});
    }
}


module.exports={allproductsemp, productsidemp, createproductemp, updateproductemp, deleteproductemp};