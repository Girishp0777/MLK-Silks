const employee = require('../../../model/Employee');


const getallemployee = async(req, res)=>{
    try{
        const allEmployee = await employee.find();
        if(!allEmployee){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(allEmployee);
        }
    }catch(Error){
        console.log(Error)
        return res.status(500).json({message:"Internal server Error"});
    }
};

const getallemployeeid = async(req, res)=>{
    try{
        const allEmployee = await employee.findById(req.params.id);
        if(!allEmployee){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json(allEmployee);
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal server Error"});
    }
};


const updateemployee = async(req, res)=>{
    try{
        const allEmployee = await employee.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true}
            );
        if(!allEmployee){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json({message:"Sucessfully  Updated",allEmployee});
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
}


const deleteemployee= async(req, res)=>{
    try{
        const allEmployee = await employee.findByIdAndDelete(req.params.id);
        if(!allEmployee){
            return res.status(404).json({message:"Id Not Found"});
        }else{
            return res.status(200).json({message:"Sucessfully Deleted",allEmployee});
        }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
}


module.exports={ getallemployee, getallemployeeid, updateemployee, deleteemployee};