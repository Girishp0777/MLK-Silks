const employee = require('../../../model/Employee');
const multer= require('multer');
const path=require('path');
const bcrypt= require('bcrypt');
const jwt= require('jsonwebtoken');

const storage = multer.diskStorage({
    destination: path.join("employee/Images"),
    filename: function (req, file, cb) {
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
  });
  
  const fileFilter = (req, file, cb) => {
    const allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedFileTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limits: { fileSize: 100000000 },
    fileFilter: fileFilter,
  }).fields([
    { name: "uidNumber", maxCount: 1 },
    { name: "panNumber", maxCount: 1 },
    { name: "passportPhoto", maxCount: 1 },
    { name: "Signature", maxCount: 1 }
  ]);


const signup = async(req, res)=>{
    try{
        upload(req, res, async(err)=>{
            if(err){
                console.log(err);
                return res.status(404).json({message:"Multer Error"});
            }

            if(!req.files || !req.files.uidNumber || !req.files.panNumber || !req.files.passportPhoto || !req.files.Signature ){
                console.log("Images Are Not Selected");
                return res.status(404).json({message:"Images Are Not Selected"});
            }

            const uidNumber = {
                data: req.files.uidNumber[0].buffer,
                contentType: req.files.uidNumber[0].mimetype,
                path: path.join("employee",  "Images", req.files.uidNumber[0].filename)
            }

            const panNumber = {
                data: req.files.panNumber[0].buffer,
                contentType: req.files.panNumber[0].mimetype,
                path: path.join("employee",  "Images", req.files.panNumber[0].filename)
            }

            const passportPhoto = {
                data: req.files.passportPhoto[0].buffer,
                contentType: req.files.passportPhoto[0].mimetype,
                path: path.join("employee",  "Images", req.files.passportPhoto[0].filename)
            }

            const Signature = {
                data: req.files.Signature[0].buffer,
                contentType: req.files.Signature[0].mimetype,
                path: path.join("employee",  "Images", req.files.Signature[0].filename)
            }

            console.log("Images uploaded successfully");


        const { FirstName, MidName, LastName, Gender, Dob, Mobile1, Mobile2, email, Password, aadharCard, panCard, 
            schoolName, SchoolSubject, SchoolPercentage, SecounderySchoolName, SecounderySchoolSubject, SecounderySchoolPercentage, PrimerySchoolName,
            PrimerySchoolSubject, PrimerySchoolPercentage, addressFullName, AddressOne, AddressTwo, linemarks, 
            city, state, pincode, mobileOne, mobileTwo } = req.body

        const isStrongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/.test(Password);
        if (!isStrongPassword) {
            return res.status(400).json({ message: "Password is not strong enough" });
        }

        const existingemployee= await employee.findOne({email});
        if(existingemployee){
            return res.status(400).json({message:"This Email Id is Already Exists"});
        }

        const ispassword = await bcrypt.hash(Password, 10);
        const newemployee= new employee({
            FirstName, MidName, LastName, Gender, Dob, Mobile1, Mobile2, email, aadharCard, panCard, 
            schoolName, SchoolSubject, SchoolPercentage, SecounderySchoolName, SecounderySchoolSubject, SecounderySchoolPercentage,
            PrimerySchoolName, PrimerySchoolSubject, PrimerySchoolPercentage, addressFullName, AddressOne, 
            AddressTwo, linemarks, city, state, pincode, mobileOne, mobileTwo,
            uidNumber:uidNumber,
            panNumber:panNumber,
            passportPhoto:passportPhoto,
            Signature:Signature,
            Password:ispassword,
        });

        await newemployee.save().then((newemployee) =>{
            return res.status(200).json({message:"Registered Sucessfully",newemployee});
        });
    });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const signin = async(req, res)=>{
    const email= req.body.email;
    const Password= req.body.Password;

    const existingemployee = await employee.findOne({email});
    if(!existingemployee){
        return res.status(404).json({message:"Employee Not Found Please Register"});
    }

    const newemployee = await employee.findOne({email});
    const ispassword = await bcrypt.compare(Password, newemployee.Password);
    if(!ispassword){
        return res.status(404).json({message:"Incorrect EmailId And Password...."});
    }
    const accesstoken =  jwt.sign(
        {
            id:newemployee._id,
        },
        process.env.JWT_EMPLOYEE_KEY,
        {
            expiresIn:"15m"
        }
    );

    console.log(accesstoken);

    if(req.cookies[`${newemployee.id}`]){
        req.cookies[`${newemployee.id}`] = " ";
    }

    res.cookie(String(newemployee.id),accesstoken, {
        path: "/",
        expires: new Date(Date.now() + 1000 *9600),
        httpOnly: true,
        sameSite: "lax",
    });
    return res.status(200).json({message: "successfully logged in",newemployee,accesstoken});
};


const currentEmployee = async(req, res)=>{
    try{
    const employees= req.newemployee;
    console.log(employees);
    const current = await  employee.findById(employees, "-Passwoed")
    if(!current){
        return res.status(404).json({message:"Employee Not Found"});
    }else{
        return res.status(200).json(current);
    }
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const signout= async(req, res)=>{
    try{
        const cookie = req.headers.cookie;
        const accesstoken= cookie?.split("=")[1];

        if(!accesstoken){
            return res.status(404).json({message:"Not Found Token"});
        }

        jwt.verify(accesstoken, process.env.JWT_EMPLOYEE_KEY,(Error, newemployee)=>{
            if(Error){
                return res.status(400).json({message:"Invalid Token or Empty Token"});
            }

            res.clearCookie(`${newemployee.id}`);
            req.cookies[`${newemployee.id}`]="";
            return res.status(200).json({message:"Sucessfully Logout"});
        });
    }catch(Error){
        console.log(Error);
        return res.status(500).json({message:"Internal server Error"});
    }
}



module.exports={signup, signin, currentEmployee, signout};